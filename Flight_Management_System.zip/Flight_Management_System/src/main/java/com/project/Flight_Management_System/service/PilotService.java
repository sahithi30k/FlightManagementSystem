package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.PilotDao;
import com.project.Flight_Management_System.dto.Pilot;
import com.project.Flight_Management_System.exception.PilotIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;
@Service
public class PilotService {
	@Autowired
	PilotDao pilotDao;
	@Autowired
	ResponseStructure<Pilot> responseStructure;
	@Autowired
	ResponseStructureAll<Pilot> responseStructureAll;

	public   ResponseStructure<Pilot> savePilot(Pilot pilot) {
		responseStructure.setMessage("Sucessfully Pilot saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(pilotDao.savePilot(pilot));
		return responseStructure;
	}
	
	public  ResponseStructure<Pilot> fetchPilotById(int pilotId) {
	Pilot pilot = pilotDao.fetchPilotById(pilotId);
		if (pilot != null) {
			responseStructure.setMessage("Sucessfully Pilot fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(pilotDao.fetchPilotById(pilotId));
			return responseStructure;
		}else {
			throw new PilotIdNotFound();
		}
	}

	
	public  ResponseStructure<Pilot> deletePilotById(int pilotId) {
		Pilot pilot = pilotDao.fetchPilotById(pilotId);
		if (pilot != null) {
		responseStructure.setMessage("Sucessfully Pilot deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(pilotDao.deletePilotById(pilotId));
		return responseStructure;
	}else {
		throw new PilotIdNotFound();
	}
}
	
	public  ResponseStructure<Pilot> updatePilotById(int oldPilotId, Pilot newPilot) {
		Pilot pilot = pilotDao.fetchPilotById(oldPilotId);
		if (pilot != null) {
	
		responseStructure.setMessage("Sucessfully Pilot updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(pilotDao.updatePilotById(oldPilotId, newPilot));
		return responseStructure;
	}else {
		throw new PilotIdNotFound();
	}
}
	public ResponseStructure<Pilot> fetchAllPilot(){
		responseStructureAll.setMessage("Sucessfully  all Pilot fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData( pilotDao.fetchAllPilot());
		return responseStructure;
	}


}

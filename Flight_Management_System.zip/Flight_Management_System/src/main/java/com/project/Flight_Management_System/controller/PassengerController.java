package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Food;
import com.project.Flight_Management_System.dto.Passenger;
import com.project.Flight_Management_System.dto.Ticket;
import com.project.Flight_Management_System.service.PassengerService;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class PassengerController {
	@Autowired
	PassengerService passengerService;
	@Operation(summary = "Save passenger", description = "API is used to save the passenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  passenger created"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PostMapping("/savePassenger")
	public ResponseStructure<Passenger>  savePassenger(@RequestBody  Passenger passenger) {
		return passengerService.savePassenger(passenger);
	}
	@Operation(summary = "Fetched passenger", description = "API is used to fetch the passenger")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully  passenger fetched "),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@GetMapping("/fetchPassengerById")
	public ResponseStructure<Passenger> fetchPassengerById(@RequestParam  int passengerId) {
	 return passengerService.fetchPassengerById(passengerId);
	}

	@DeleteMapping("/deletePassengerById")
	public ResponseStructure<Passenger> deletePassengerById(@RequestParam  int passengerId) {
		
	 return passengerService.deletePassengerById(passengerId);
	}
	@PutMapping("/updatepassengerById")
	public ResponseStructure<Passenger> updatepassengerById(@RequestParam   int oldPassengerId,@RequestBody   Passenger newPassenger) {
		 return  passengerService.updatepassengerById(oldPassengerId, newPassenger);
	}
	@GetMapping("/fetchAllPassenger")
	public ResponseStructureAll<Passenger> fetchAllPassenger(){
		return passengerService.fetchAllPassenger();
	}
	@PutMapping("/addExistingSeatToExistingPassenger")
	public ResponseStructure<Passenger> addExistingSeatToExistingPassenger(@RequestParam int passengerId,@RequestParam  int seatId) {
		return passengerService.addExistingSeatToExistingPassenger(passengerId, seatId);
	}
	@PutMapping("/addExistingPassportToExistingPassenger")
	public ResponseStructure<Passenger> addExistingPassportToExistingPassenger(@RequestParam  int passengerId, @RequestParam  int passportId) {
		return passengerService.addExistingPassportToExistingPassenger(passengerId, passportId);
	}
	@PutMapping("/addExistingFoodToExistingPassenger")
	public ResponseStructure<Passenger> addExistingFoodToExistingPassenger(@RequestParam  int passengerId,@RequestParam  int foodId) {
		return passengerService.addExistingFoodToExistingPassenger(passengerId, foodId);
		}
	@PutMapping("/addNewFoodToExistingPassenger")
	public ResponseStructure<Passenger> addNewFoodToExistingPassenger(@RequestParam  int passengerId,@RequestBody  Food newFood) {
		return passengerService.addNewFoodToExistingPassenger(passengerId, newFood);
	}
	@PutMapping("/addExistingTicketToExistingPassenger")
	public ResponseStructure<Passenger> addExistingTicketToExistingPassenger(@RequestParam  int passengerId,@RequestParam  int ticketId) {
		return passengerService.addExistingTicketToExistingPassenger(passengerId, ticketId);
	}
	@PutMapping("/addNewTicketToExistingPassenger")
	public ResponseStructure<Passenger> addNewTicketToExistingPassenger(@RequestParam  int passengerId,@RequestBody  Ticket newTicket) {
		return passengerService.addNewTicketToExistingPassenger(passengerId, newTicket);
	}
}

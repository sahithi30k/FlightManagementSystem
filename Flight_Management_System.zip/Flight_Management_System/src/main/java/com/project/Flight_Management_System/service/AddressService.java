package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.AddressDao;
import com.project.Flight_Management_System.dto.Address;
import com.project.Flight_Management_System.exception.AddressIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;

@Service
public class AddressService {

	@Autowired
	AddressDao addressDao;
	@Autowired
	ResponseStructure<Address> responseStructure;
	@Autowired
	ResponseStructureAll<Address> responseStructureAll;

	public ResponseStructure<Address> saveAddress(Address address) {
		responseStructure.setMessage("Sucessfully Address saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(addressDao.saveAddress(address));
		return responseStructure;
	}

	public ResponseStructure<Address> fetchAddressById(int addressId) {
		Address address = addressDao.fetchAddressById(addressId);
		if (address != null) {
			responseStructure.setMessage("Sucessfully Address fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(addressDao.fetchAddressById(addressId));
			return responseStructure;
		} else {
			throw new AddressIdNotFound();
		}
	}

	public ResponseStructure<Address> deleteAddressById(int addressId) {
		Address address = addressDao.fetchAddressById(addressId);
		if(address!=null) {
		responseStructure.setMessage("Sucessfully Address deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(addressDao.deleteAddressById(addressId));
		return responseStructure;
	}
		else {
			throw new AddressIdNotFound();
		}
		}
	public ResponseStructure<Address> UpdateAddressById(int oldAddressId, Address newAddress) {
		Address address = addressDao.fetchAddressById(oldAddressId);
		if(address!=null) {
		responseStructure.setMessage("Sucessfully Airport updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(addressDao.UpdateAddressById(oldAddressId, newAddress));
		return responseStructure;
	}else {
		throw new AddressIdNotFound();
	}}

	public ResponseStructure<Address> fetchAllAddress() {
		responseStructureAll.setMessage("Sucessfully  all Addressess fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(addressDao.fetchAllAddress());
		return responseStructure;
	}

}

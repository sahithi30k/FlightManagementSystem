package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Food;
import com.project.Flight_Management_System.service.FoodService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class FoodController {
	@Autowired
	FoodService foodService;
	@Operation(summary = "Save food", description = "API is used to save the food")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  food created"),
			@ApiResponse(responseCode = "404", description = "food not found for the given id") })
	@PostMapping("/saveFood")
	public ResponseStructure<Food>  saveFood(@RequestBody  Food food) {
		return foodService.saveFood(food);
	}
	@Operation(summary = "Fetched food", description = "API is used to fetch the food")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully  food fetched "),
			@ApiResponse(responseCode = "404", description = "food not found for the given id") })
	@GetMapping("/fetchFoodById")
	public ResponseStructure<Food> fetchFoodById(@RequestParam  int foodId) {
	 return foodService.fetchFoodById(foodId);
	}

	@DeleteMapping("/deleteFoodById")
	public ResponseStructure<Food> deleteFoodById(@RequestParam  int foodId) {
		
	 return foodService.deleteFoodById(foodId);
	}
	@PutMapping("/updateFoodById")
	public ResponseStructure<Food> updateFoodById(@RequestParam  int oldFoodId,@RequestBody   Food newFood) {
		 return  foodService.updateFoodById(oldFoodId, newFood);
	}
	@GetMapping("/fetchAllFood")
	public ResponseStructure<Food> fetchAllFood(){
		return foodService.fetchAllFood();
	}
}

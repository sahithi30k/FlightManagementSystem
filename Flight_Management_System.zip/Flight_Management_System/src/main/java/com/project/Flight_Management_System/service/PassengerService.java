package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.PassengerDao;
import com.project.Flight_Management_System.dto.Food;
import com.project.Flight_Management_System.dto.Passenger;
import com.project.Flight_Management_System.dto.Ticket;
import com.project.Flight_Management_System.exception.PassengerIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;
@Service
public class PassengerService {
	@Autowired
	PassengerDao passengerDao;
	@Autowired
	ResponseStructure<Passenger> responseStructure;
	@Autowired
	ResponseStructureAll<Passenger> responseStructureAll;


	public   ResponseStructure<Passenger> savePassenger(Passenger passenger) {
		responseStructure.setMessage("Sucessfully Passenger saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(passengerDao.savePassenger(passenger));
		return responseStructure;
		
	}
	
	public  ResponseStructure<Passenger> fetchPassengerById(int passengerId) {
		Passenger passenger = passengerDao.fetchPassengerById(passengerId);
		if (passenger != null) {
			responseStructure.setMessage("Sucessfully Passenger fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(passengerDao.fetchPassengerById(passengerId));
			return responseStructure;
		}else {
			throw new PassengerIdNotFound();
		}
	}

	
	public  ResponseStructure<Passenger> deletePassengerById(int passengerId) {
		Passenger passenger = passengerDao.fetchPassengerById(passengerId);
		if (passenger != null) {
		responseStructure.setMessage("Sucessfully Passenger deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.deletePassengerById(passengerId));
		return responseStructure;
	
	}else {
		throw new PassengerIdNotFound();
	}
}
	
	public  ResponseStructure<Passenger> updatepassengerById(int oldPassengerId, Passenger newPassenger) {
		Passenger passenger = passengerDao.fetchPassengerById(oldPassengerId);
		if (passenger != null) {
	
		responseStructure.setMessage("Sucessfully Passenger updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.updatepassengerById(oldPassengerId, newPassenger));
		return responseStructure;
	}else {
		throw new PassengerIdNotFound();
	}
}
	public  ResponseStructureAll<Passenger> fetchAllPassenger(){
		responseStructureAll.setMessage("Sucessfully  all Passengers fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(passengerDao.fetchAllPassenger());
		return responseStructureAll;
	}
	
	public  ResponseStructure<Passenger> addExistingSeatToExistingPassenger(int passengerId,int seatId) {
//		return passengerDao.addExistingSeatToExistingPassenger(passengerId, seatId);
		responseStructure.setMessage("Sucessfully addExistingSeatToExistingPassenger in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addExistingSeatToExistingPassenger(passengerId, seatId));
		return responseStructure;
	}
	public   ResponseStructure<Passenger> addExistingPassportToExistingPassenger(int passengerId, int passportId) {
		//return passengerDao.addExistingPassportToExistingPassenger(passengerId, passportId);
		responseStructure.setMessage("Sucessfully  addExistingPassportToExistingPassenger  in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addExistingPassportToExistingPassenger(passengerId, passportId));
		return responseStructure;
	}
	public  ResponseStructure<Passenger> addExistingFoodToExistingPassenger(int passengerId,int foodId) {
	//return passengerDao.addExistingFoodToExistingPassenger(passengerId, foodId);
	responseStructure.setMessage("SucessfullyaddExistingFoodToExistingPassenger in the DB");
	responseStructure.setStatusCode(HttpStatus.OK.value());
	responseStructure.setData( passengerDao.addExistingFoodToExistingPassenger(passengerId, foodId));
	return responseStructure;
	}
	public  ResponseStructure<Passenger> addNewFoodToExistingPassenger(int passengerId,Food newFood) {
		//return passengerDao.addNewFoodToExistingPassenger(passengerId, newFood);
		responseStructure.setMessage("Sucessfully addNewFoodToExistingPassenger  in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addNewFoodToExistingPassenger(passengerId, newFood));
		return responseStructure;
	}
	public  ResponseStructure<Passenger> addExistingTicketToExistingPassenger(int passengerId,int ticketId) {
		//return passengerDao.addExistingTicketToExistingPassenger(passengerId, ticketId);
		responseStructure.setMessage("Sucessfully addExistingTicketToExistingPassenger  in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData( passengerDao.addExistingTicketToExistingPassenger(passengerId, ticketId));
		return responseStructure;
	}
	public  ResponseStructure<Passenger> addNewTicketToExistingPassenger(int passengerId, Ticket newTicket) {
//		return passengerDao.addNewTicketToExistingPassenger(passengerId, newTicket);
		responseStructure.setMessage("Sucessfully addNewTicketToExistingPassenger  in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passengerDao.addNewTicketToExistingPassenger(passengerId, newTicket));
		return responseStructure;
	}
}

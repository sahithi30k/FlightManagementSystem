package com.project.Flight_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.project.Flight_Management_System.dto.Food;
import com.project.Flight_Management_System.dto.Passenger;
import com.project.Flight_Management_System.dto.Passport;
import com.project.Flight_Management_System.dto.Seat;
import com.project.Flight_Management_System.dto.Ticket;
import com.project.Flight_Management_System.repo.PassengerRepo;

@Repository
public class PassengerDao {
	@Autowired
	PassengerRepo passengerRepo;

	@Autowired
	SeatDao seatDao;
	@Autowired
	PassportDao passportDao;
	@Autowired
	FoodDao foodDao; 
	@Autowired
	TicketDao ticketDao;

	public Passenger savePassenger(Passenger passenger) {
		return passengerRepo.save(passenger);
	}

	public Passenger fetchPassengerById(int passengerId) {
		 Optional<Passenger> passenger=passengerRepo.findById(passengerId);
		 if(passenger.isPresent()) {
			 return passenger.get();
		 }else {
			 return null;
		 }
	}

	public Passenger deletePassengerById(int passengerId) {
		Passenger passenger = fetchPassengerById(passengerId);
		passengerRepo.delete(passenger);
		return passenger;
	}

	public Passenger updatepassengerById(int oldPassengerId, Passenger newPassenger) {
		newPassenger.setPassengerId(oldPassengerId);
		return passengerRepo.save(newPassenger);
	}

	public List<Passenger> fetchAllPassenger() {
		return passengerRepo.findAll();
	}
	public Passenger addExistingSeatToExistingPassenger(int passengerId,int seatId) {
		Passenger passenger=fetchPassengerById(passengerId);
		Seat seat=seatDao.fetchSeatById(seatId);
		passenger.setSeat(seat);
		return passengerRepo.save(passenger);
	}

	public Passenger addExistingPassportToExistingPassenger(int passengerId, int passportId) {
		Passenger passenger = fetchPassengerById(passengerId);
		Passport passport = passportDao.fetchPassportById(passportId);
		passenger.setPassport(passport);
		return passengerRepo.save(passenger);
	}
	public Passenger addExistingFoodToExistingPassenger(int passengerId,int foodId) {
		Passenger passenger = fetchPassengerById(passengerId);
		Food food = foodDao.fetchFoodById(foodId);
		List<Food> list= passenger.getFoods();
		list.add(food);
		passenger.setFoods(list);
		return savePassenger(passenger);
	}
	public Passenger addNewFoodToExistingPassenger(int passengerId,Food newFood) {
		Passenger passenger = fetchPassengerById(passengerId);
		List<Food> list= passenger.getFoods();
		list.add(newFood);
		passenger.setFoods(list);
		return savePassenger(passenger);
	}
	public Passenger addExistingTicketToExistingPassenger(int passengerId,int ticketId) {
		Passenger passenger= fetchPassengerById(passengerId);
		Ticket ticket=ticketDao.fetchTicketById(ticketId);
		List<Ticket> list = passenger.getTickets();
		list.add(ticket);
		passenger.setTickets(list);
		return savePassenger(passenger);
	}
	public Passenger addNewTicketToExistingPassenger(int passengerId, Ticket newTicket) {
		Passenger passenger= fetchPassengerById(passengerId);
		List<Ticket> list = passenger.getTickets();
		list.add(newTicket);
		passenger.setTickets(list);
		return savePassenger(passenger);
	}
}

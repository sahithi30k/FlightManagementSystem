package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Airhostess;
import com.project.Flight_Management_System.dto.Flight;
import com.project.Flight_Management_System.dto.Passenger;
import com.project.Flight_Management_System.dto.Pilot;
import com.project.Flight_Management_System.service.FlightService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class FlightController {
	@Autowired
	FlightService flightService;
	@Operation(summary = "Save flight", description = "API is used to save the flight")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  flight created"),
			@ApiResponse(responseCode = "404", description = "flight not found for the given id") })
	@PostMapping("/saveFlight")
	public ResponseStructure<Flight> saveFlight(@RequestBody Flight flight) {

		return flightService.saveFlight(flight);
	}
	@Operation(summary = "Fetched flight", description = "API is used to fetch the flight")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully  flight fetched "),
			@ApiResponse(responseCode = "404", description = "flight not found for the given id") })
	@GetMapping("/fetchFlightById")
	public ResponseStructure<Flight> fetchFlightById(@RequestParam int flightId) {

		return flightService.fetchFlightById(flightId);
	}

	@DeleteMapping("/deleteFlightById")
	public ResponseStructure<Flight> deleteFlightById(@RequestParam int flightId) {

		return flightService.deleteFlightById(flightId);
	}

	@PutMapping("/UpdateFLightById")
	public ResponseStructure<Flight> UpdateFLightById(@RequestParam int oldFlightId, @RequestBody Flight newFlight) {

		return flightService.UpdateFLightById(oldFlightId, newFlight);
	}

	@GetMapping("/fetchAllFlight")
	public ResponseStructure<Flight> fetchAllFlight() {
		return flightService.fetchAllFlight();
	}

	@PutMapping("/addExistingAirhostessToExistingFlight")
	public ResponseStructure<Flight> addExistingAirhostessToExistingFlight(@RequestParam   int airhostessId,@RequestParam int flightId) {
		return flightService.addExistingAirhostessToExistingFlight(airhostessId, flightId);
	}
	@PutMapping("/addNewAirhostessToExistingFlight")
	public ResponseStructure<Flight> addNewAirhostessToExistingFlight(@RequestParam  int flightId,@RequestBody Airhostess newAirhostess) {
		return flightService.addNewAirhostessToExistingFlight(flightId, newAirhostess);
	}
	@PutMapping("/addExistingPilotToExistingFlight")
	public ResponseStructure<Flight> addExistingPilotToExistingFlight(@RequestParam  int pilotId,@RequestParam int flightId) {
		return flightService.addExistingPilotToExistingFlight(pilotId, flightId);
	}
	@PutMapping("/addNewPilotToExistingFlight")
	public ResponseStructure<Flight> addNewPilotToExistingFlight(@RequestParam  int flightId,@RequestBody Pilot newPilot) {
		return flightService.addNewPilotToExistingFlight(flightId, newPilot);

	}
	@PutMapping("/addExistingPassengerToExistingFlight")
	public ResponseStructure<Flight> addExistingPassengerToExistingFlight(@RequestParam  int passengerId,@RequestParam  int flightId) {
		return flightService.addExistingPassengerToExistingFlight(passengerId, flightId);
	}
	@PutMapping("/addNewPassengerToExistingFlight")
	public ResponseStructure<Flight> addNewPassengerToExistingFlight(@RequestParam  int flightId,@RequestBody   Passenger newPassenger) {
		return flightService.addNewPassengerToExistingFlight(flightId, newPassenger);
	}
	
}

package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.FoodDao;
import com.project.Flight_Management_System.dto.Food;
import com.project.Flight_Management_System.exception.FoodIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;
@Service
public class FoodService {
@Autowired
FoodDao foodDao;
@Autowired
ResponseStructure<Food> responseStructure;
@Autowired
ResponseStructureAll<Food> responseStructureAll;

	
	public ResponseStructure<Food>  saveFood(Food food) {
		responseStructure.setMessage("Sucessfully Food saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(foodDao.saveFood(food));
		return responseStructure;
	}
	
	public  ResponseStructure<Food> fetchFoodById(int foodId) {
		Food food = foodDao.fetchFoodById(foodId);
		if (food != null) {
			responseStructure.setMessage("Sucessfully Food fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(foodDao.fetchFoodById(foodId));
			return responseStructure;
		}else {
			throw new  FoodIdNotFound();
		}
	}

	
	public  ResponseStructure<Food> deleteFoodById(int foodId) {
		Food food = foodDao.fetchFoodById(foodId);
		if (food != null) {
		responseStructure.setMessage("Sucessfully Food deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(foodDao.deleteFoodById(foodId));
		return responseStructure;	
	}else {
		throw new  FoodIdNotFound();
	}
}
	
	public  ResponseStructure<Food> updateFoodById(int oldFoodId, Food newFood) {
		Food food = foodDao.fetchFoodById(oldFoodId);
		if (food != null) {
	
		responseStructure.setMessage("Sucessfully Food updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData( foodDao.updateFoodById(oldFoodId, newFood));
		return responseStructure;
	}else {
		throw new  FoodIdNotFound();
	}
}
	public  ResponseStructure<Food> fetchAllFood(){
		responseStructureAll.setMessage("Sucessfully  all Foods fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(foodDao.fetchAllFood());
		return responseStructure; 
	}
}

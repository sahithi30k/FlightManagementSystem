package com.project.Flight_Management_System.exception;

public class PilotIdNotFound extends RuntimeException{
	private String message="Pilot Id not found in the DB";
	public String getMessage() {
		return message;
	}
}

package com.project.Flight_Management_System.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Airport;
import com.project.Flight_Management_System.dto.Flight;
import com.project.Flight_Management_System.service.AirportService;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class AirportController {

	@Autowired
	AirportService airportService;
	@Operation(summary = "Save Airport", description = "API is used to save the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  airport created"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PostMapping("/saveAirport")
	public ResponseStructure<Airport> saveAirport(@RequestBody    Airport airport) {
		return airportService.saveAirport(airport);
	}
	@GetMapping("/fetchAirportById")
	public ResponseStructure<Airport> fetchAirportById(@RequestParam  int airportId) {
	 return airportService.fetchAirportById(airportId);
	}

	@DeleteMapping("/deleteAirportById")
	public ResponseStructure<Airport> deleteAirportById(@RequestParam   int airportId) {
		
	 return airportService.deleteAirportById(airportId);
	}
	@PutMapping("/updateAirportById")
	public ResponseStructure<Airport> updateAirportById(@RequestParam  int oldAirportId,@RequestBody  Airport newAirport) {
	 return  airportService.updateAirportById(oldAirportId, newAirport);
	}
	@GetMapping("/fetchAllAirport")
	public ResponseStructureAll<Airport> fetchAllAirport(){
		return airportService.fetchAllAirport();
	}
	@PutMapping("/addExistingAddressToExistingAirport")
	public ResponseStructure<Airport> addExistingAddressToExistingAirport(@RequestParam int addressId,@RequestParam  int airportId) {
		return airportService.addExistingAddressToExistingAirport(addressId, airportId);
	}
	@PutMapping("/addExistingFlightToExistingAirport")
	public ResponseStructure<Airport> addExistingFlightToExistingAirport(@RequestParam  int flightId,@RequestParam int airportId) {
		return airportService.addExistingFlightToExistingAirport( flightId,airportId);
	}
	@PutMapping("/addNewFlightToExistingAirport")
	public ResponseStructure<Airport> addNewFlightToExistingAirport(@RequestParam  int airportId,@RequestBody  Flight newFlight) {
		return airportService.addNewFlightToExistingAirport(airportId, newFlight);
	}
}

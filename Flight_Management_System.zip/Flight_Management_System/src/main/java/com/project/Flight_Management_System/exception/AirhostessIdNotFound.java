package com.project.Flight_Management_System.exception;

public class AirhostessIdNotFound extends RuntimeException{
	private String message="airhostess Id not found in the DB";
	public String getMessage() {
		return message;
	}
}

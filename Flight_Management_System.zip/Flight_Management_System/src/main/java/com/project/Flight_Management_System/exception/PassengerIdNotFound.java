package com.project.Flight_Management_System.exception;

public class PassengerIdNotFound extends RuntimeException{
	private String message="Passenger Id not found in the DB";
	public String getMessage() {
		return message;
	}
}

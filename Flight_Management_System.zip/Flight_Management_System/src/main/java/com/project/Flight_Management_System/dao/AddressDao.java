package com.project.Flight_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Flight_Management_System.dto.Address;
import com.project.Flight_Management_System.repo.AddressRepo;

@Repository
public class AddressDao {

	@Autowired
	AddressRepo addressRepo;

	public Address saveAddress(Address address) {

		return addressRepo.save(address);
	}

	public Address fetchAddressById(int addressId) {
		Optional<Address> address = addressRepo.findById(addressId);
		if (address.isPresent()) {
			return address.get();
		} else {

			return null;
		}
	}

	public Address deleteAddressById(int addressId) {
		Address address = fetchAddressById(addressId);
		addressRepo.delete(address);
		return address;
	}

	public Address UpdateAddressById(int oldAddressId, Address newAddress) {
		newAddress.setAddressId(oldAddressId);
		return addressRepo.save(newAddress);
	}

	public List<Address> fetchAllAddress() {
		return addressRepo.findAll();
	}
}

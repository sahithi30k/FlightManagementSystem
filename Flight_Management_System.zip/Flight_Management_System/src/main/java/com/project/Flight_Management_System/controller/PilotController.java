package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Pilot;
import com.project.Flight_Management_System.service.PilotService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class PilotController {
@Autowired
PilotService pilotService;
@Operation(summary = "Save pilot", description = "API is used to save the pilot")
@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  pilot created"),
		@ApiResponse(responseCode = "404", description = "pilot not found for the given id") })
	@PostMapping("/savePilot")
	public ResponseStructure<Pilot>  savePilot(@RequestBody  Pilot pilot) {
		return pilotService.savePilot(pilot);
	}
	@GetMapping("/fetchPilotById")
	public ResponseStructure<Pilot> fetchPilotById(@RequestParam  int pilotId) {
	 return pilotService.fetchPilotById(pilotId);
	}

	@DeleteMapping("/deletePilotById")
	public ResponseStructure<Pilot> deletePilotById(@RequestParam  int pilotId) {
	 return pilotService.deletePilotById(pilotId);
	}
	@PutMapping("/updatePilotById")
	public ResponseStructure<Pilot> updatePilotById(@RequestParam  int oldPilotId,@RequestBody Pilot newPilot) {
		 return  pilotService.updatePilotById(oldPilotId, newPilot);
	}
	@GetMapping("/fetchAllPilot")
	public ResponseStructure<Pilot> fetchAllPilot(){
		return pilotService.fetchAllPilot();
	}

}

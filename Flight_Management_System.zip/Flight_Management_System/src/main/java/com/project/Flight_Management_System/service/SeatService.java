package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.SeatDao;
import com.project.Flight_Management_System.dto.Seat;
import com.project.Flight_Management_System.exception.SeatIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;
@Service
public class SeatService {
	@Autowired
	SeatDao seatDao;
	@Autowired
	ResponseStructure<Seat> responseStructure;
	@Autowired
	ResponseStructureAll<Seat> responseStructureAll;

	
	public  ResponseStructure<Seat> saveSeat(Seat seat) {
		responseStructure.setMessage("Sucessfully Seat saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(seatDao.saveSeat(seat));
		return responseStructure;
	}
	
	public  ResponseStructure<Seat> fetchSeatById(int seatId) {
		Seat seat = seatDao.fetchSeatById(seatId);
		if (seat != null) {
			responseStructure.setMessage("Sucessfully Seat fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(seatDao.fetchSeatById(seatId));
			return responseStructure;
		}else {
			throw new SeatIdNotFound();
		}
	}

	
	public  ResponseStructure<Seat> deleteSeatById(int seatId) {
		Seat seat = seatDao.fetchSeatById(seatId);
		if (seat != null) {
		responseStructure.setMessage("Sucessfully Seat deleted from the DB");
	responseStructure.setStatusCode(HttpStatus.OK.value());
	responseStructure.setData(seatDao.deleteSeatById(seatId));
	return responseStructure;
	}else {
		throw new SeatIdNotFound();
	}
}

	
	public  ResponseStructure<Seat> updateSeatById(int oldSeatId, Seat newSeat) {
		Seat seat = seatDao.fetchSeatById(oldSeatId);
		if (seat != null) {
	
		responseStructure.setMessage("Sucessfully Airport updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(seatDao.updateSeatById(oldSeatId, newSeat));
		return responseStructure;
	}else {
		throw new SeatIdNotFound();
	}
}

	public  ResponseStructure<Seat> fetchAllSeat(){
		responseStructureAll.setMessage("Sucessfully  all Seat fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(seatDao.fetchAllSeat());
		return responseStructure;
	}



}

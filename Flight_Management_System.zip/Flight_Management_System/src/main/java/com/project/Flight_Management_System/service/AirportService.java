package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.AirportDao;
import com.project.Flight_Management_System.dto.Airport;
import com.project.Flight_Management_System.dto.Flight;
import com.project.Flight_Management_System.exception.AirportIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;

@Service
public class AirportService {
	@Autowired
	AirportDao airportDao;
	@Autowired
	ResponseStructure<Airport> responseStructure;
	@Autowired
	ResponseStructureAll<Airport> responseStructureAll;

	public ResponseStructure<Airport> saveAirport(Airport airport) {
		// return airportDao.saveAirport(airport);
		responseStructure.setMessage("Sucessfully Airport saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(airportDao.saveAirport(airport));
		return responseStructure;
	}

	public ResponseStructure<Airport> fetchAirportById(int airportId) {
		// return airportDao.fetchAirportById(airportId);

		Airport airport = airportDao.fetchAirportById(airportId);
		if (airport != null) {
			responseStructure.setMessage("Sucessfully Airport fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(airportDao.fetchAirportById(airportId));
			return responseStructure;
		} else {
			throw new AirportIdNotFound();
		}

	}

	public ResponseStructure<Airport> deleteAirportById(int airportId) {
		// return airportDao.deleteAirportById(airportId);

		Airport airport = airportDao.fetchAirportById(airportId);
		if (airport != null) {
			responseStructure.setMessage("Sucessfully Airport deleted from the DB");
			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setData(airportDao.deleteAirportById(airportId));
			return responseStructure;
		} else {
			throw new AirportIdNotFound();
		}
	}

	public ResponseStructure<Airport> updateAirportById(int oldAirportId, Airport newAirport) {
		// return airportDao.updateAirportById(oldAirportId, newAirport);
		Airport airport = airportDao.fetchAirportById(oldAirportId);
		if (airport != null) {
			responseStructure.setMessage("Sucessfully Airport updated in the DB");
			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setData(airportDao.updateAirportById(oldAirportId, newAirport));
			return responseStructure;
		} else {
			throw new AirportIdNotFound();
		}
	}

	public ResponseStructureAll<Airport> fetchAllAirport() {
		// return airportDao.fetchAllAirport();
		responseStructureAll.setMessage("Sucessfully  all Airports fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(airportDao.fetchAllAirport());
		return responseStructureAll;
	}

	public ResponseStructure<Airport> addExistingAddressToExistingAirport(int addressId, int airportId) {
		// return airportDao.addExistingAddressToExistingAirport(addressId, airportId);
		responseStructure.setMessage("Sucessfully Airport updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(airportDao.addExistingAddressToExistingAirport(addressId, airportId));
		return responseStructure;
	}

	public   ResponseStructure<Airport> addExistingFlightToExistingAirport(int flightId, int airportId) {
//		return airportDao.addExistingFlightToExistingAirport(flightId, airportId);
		responseStructure.setMessage("Sucessfully Airport updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(airportDao.addExistingFlightToExistingAirport(flightId, airportId));
		return responseStructure;
	}

	public  ResponseStructure<Airport> addNewFlightToExistingAirport(int airportId, Flight newFlight) {
//		return airportDao.addNewFlightToExistingAirport(airportId, newFlight);
		responseStructure.setMessage("Sucessfully Airport updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(airportDao.addNewFlightToExistingAirport(airportId, newFlight));
		return responseStructure;
	}
}

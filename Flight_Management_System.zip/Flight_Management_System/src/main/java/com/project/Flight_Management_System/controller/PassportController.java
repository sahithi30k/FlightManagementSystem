package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Passport;
import com.project.Flight_Management_System.service.PassportService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class PassportController {
	@Autowired
	PassportService passportService;
	@Operation(summary = "Save passport", description = "API is used to save the passport")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  passport created"),
			@ApiResponse(responseCode = "404", description = "passport not found for the given id") })
	@PostMapping("/savePassport")
	public ResponseStructure<Passport> savePassport(@RequestBody   Passport passport) {
		return passportService.savePassport(passport);

	}
@GetMapping("/fetchPassportById")
	public ResponseStructure<Passport> fetchPassportById(@RequestParam   int passportId) {
		return passportService.fetchPassportById(passportId);
	}
@DeleteMapping("/deletePassportById")
	public ResponseStructure<Passport> deletePassportById(@RequestParam  int passportId) {
		return passportService.deletePassportById(passportId);
	}
@PutMapping("/updatePassportById")
	public ResponseStructure<Passport> updatePassportById(@RequestParam   int oldPassportId,@RequestBody Passport newPassport) {

		return passportService.updatePassportById(oldPassportId, newPassport);
	}
@GetMapping("/fetchAllPassport")
	public ResponseStructure<Passport> fetchAllPassport() {
		return passportService.fetchAllPassport();
	}


}

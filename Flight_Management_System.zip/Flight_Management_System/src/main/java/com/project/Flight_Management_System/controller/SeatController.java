package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Seat;
import com.project.Flight_Management_System.service.SeatService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class SeatController {
	@Autowired
	SeatService seatService;
	@Operation(summary = "Save seat", description = "API is used to save the seat")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  seat created"),
			@ApiResponse(responseCode = "404", description = "seat not found for the given id") })
	@PostMapping("/saveSeat")
	public ResponseStructure<Seat> saveSeat(@RequestBody  Seat seat) {
		return seatService.saveSeat(seat);
	}
	@GetMapping("/fetchSeatById")
	public ResponseStructure<Seat> fetchSeatById(@RequestParam int seatId) {
	 return seatService.fetchSeatById(seatId);
	}

	@DeleteMapping("/deleteSeatById")
	public ResponseStructure<Seat> deleteSeatById(@RequestParam  int seatId) {

	 return seatService.deleteSeatById(seatId);
	}
	@PutMapping("/updateSeatById")
	public ResponseStructure<Seat> updateSeatById(@RequestParam  int oldSeatId,@RequestBody   Seat newSeat) {
		 return  seatService.updateSeatById(oldSeatId, newSeat);
	}
	@GetMapping("/fetchAllSeat")
	public ResponseStructure<Seat> fetchAllSeat(){
		return seatService.fetchAllSeat();
	}



}

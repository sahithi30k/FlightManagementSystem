package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Payment;
import com.project.Flight_Management_System.service.PaymentService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class PaymentController {
@Autowired
PaymentService paymentService;
@Operation(summary = "Save payment", description = "API is used to save the payment")
@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  payment created"),
		@ApiResponse(responseCode = "404", description = "payment not found for the given id") })
@PostMapping("/savePayment")
	public ResponseStructure<Payment>  savePayment(@RequestBody    Payment payment) {
		return paymentService.savePayment(payment);
	}
	@GetMapping("/fetchPaymentById")
	public ResponseStructure<Payment> fetchPaymentById(@RequestParam  int paymentId) {
	 return paymentService.fetchPaymentById(paymentId);
	}

@DeleteMapping("/deletePaymentById")	
	public ResponseStructure<Payment> deletePaymentById(@RequestParam  int paymentId) {
	 return paymentService.deletePaymentById(paymentId);
	}
	@PutMapping("/updatePaymentById")
	public ResponseStructure<Payment> updatePaymentById(@RequestParam  int oldPaymentId,@RequestBody Payment newPayment) {
	
		 return  paymentService.updatePaymentById(oldPaymentId, newPayment);
	}
	@GetMapping("/fetchAllPayment")
	public ResponseStructure<Payment> fetchAllPayment(){
		return paymentService.fetchAllPayment();
	}

	
}

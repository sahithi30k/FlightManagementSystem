package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.PassportDao;
import com.project.Flight_Management_System.dto.Passport;
import com.project.Flight_Management_System.exception.PassportIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;

@Service
public class PassportService {
	@Autowired
	PassportDao passportDao;
	@Autowired
	ResponseStructure<Passport> responseStructure;
	@Autowired
	ResponseStructureAll<Passport> responseStructureAll;


	public  ResponseStructure<Passport> savePassport(Passport passport) {
		responseStructure.setMessage("Sucessfully Passport saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(passportDao.savePassport(passport));
		return responseStructure;

	}

	public  ResponseStructure<Passport> fetchPassportById(int passportId) {
	Passport passport = passportDao.fetchPassportById(passportId);
		if (passport != null) {
			responseStructure.setMessage("Sucessfully Passport fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(passportDao.fetchPassportById(passportId));
			return responseStructure;
		}else {
			throw new PassportIdNotFound();
		}
	}

	public  ResponseStructure<Passport> deletePassportById(int passportId) {
		Passport passport = passportDao.fetchPassportById(passportId);
		if (passport != null) {
		responseStructure.setMessage("Sucessfully Passport deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(passportDao.deletePassportById(passportId));
		return responseStructure;
	}
		else {
			throw new PassportIdNotFound();
		}
	}
	public  ResponseStructure<Passport> updatePassportById(int oldPassportId, Passport newPassport) {
		Passport passport = passportDao.fetchPassportById(oldPassportId);
		if (passport != null) {
		responseStructure.setMessage("Sucessfully Passport updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData( passportDao.updatePassportById(oldPassportId, newPassport));
		return responseStructure;
	
	}else {
		throw new PassportIdNotFound();
	}
}

	public  ResponseStructure<Passport> fetchAllPassport() {
		responseStructureAll.setMessage("Sucessfully  all Passports fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData( passportDao.fetchAllPassport());
		return responseStructure;
	}

}

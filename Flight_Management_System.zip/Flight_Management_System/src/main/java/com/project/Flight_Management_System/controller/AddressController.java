package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Address;
import com.project.Flight_Management_System.service.AddressService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
public class AddressController {
	@Autowired
	AddressService addressService;
	@Operation(summary = "Save address", description = "API is used to save the address")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  address created"),
			@ApiResponse(responseCode = "404", description = "address not found for the given id") })
	@PostMapping("/saveAddress")
	public ResponseStructure<Address> saveAddress(@RequestBody Address address) {

		return addressService.saveAddress(address);
	}
	@Operation(summary = "Fetched Airport", description = "API is used to fetch the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully  airport fetched "),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@GetMapping("/fetchAddressById")
	public ResponseStructure<Address> fetchAddressById(@RequestParam int addressId) {
		return addressService.fetchAddressById(addressId);
	}
	@Operation(summary = "Deleted Airport", description = "API is used to deleted the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully  airport deleted"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@DeleteMapping("/deleteAddressById")
	public ResponseStructure<Address> deleteAddressById(@RequestParam int addressId) {

		return addressService.deleteAddressById(addressId);
	}
	@Operation(summary = "Updated Airport", description = "API is used to update the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successfully  airport updated"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@PutMapping("/UpdateAddressById")
	public ResponseStructure<Address> UpdateAddressById(@RequestParam int oldAddressId,
			@RequestBody Address newAddress) {

		return addressService.UpdateAddressById(oldAddressId, newAddress);
	}
	@Operation(summary = "Fetched ALl Airport", description = "API is used to fetchAll the Airport")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully  aitport Fetched"),
			@ApiResponse(responseCode = "404", description = "Airport not found for the given id") })
	@GetMapping("/fetchAllAddress")
	public ResponseStructure<Address> fetchAllAddress() {
		return addressService.fetchAllAddress();
	}

}

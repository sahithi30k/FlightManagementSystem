package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.AirhostessDao;
import com.project.Flight_Management_System.dto.Airhostess;
import com.project.Flight_Management_System.exception.AirhostessIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;

@Service
public class AirhostessService {

	@Autowired
	AirhostessDao airhostessDao;

	@Autowired
	ResponseStructure<Airhostess> responseStructure;
	@Autowired
	ResponseStructureAll<Airhostess> responseStructureAll;

	public ResponseStructure<Airhostess> saveAirhostess(Airhostess airhostess) {
		responseStructure.setMessage("Sucessfully Airhostess saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(airhostessDao.saveAirhostess(airhostess));
		return responseStructure;
	}

	public ResponseStructure<Airhostess> fetchAirhostessById(int airhostessId) {
		Airhostess airhostess = airhostessDao.fetchAirhostessById(airhostessId);
		if (airhostess != null) {
			responseStructure.setMessage("Sucessfully Airhostess fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(airhostessDao.fetchAirhostessById(airhostessId));
			return responseStructure;
		} else {
			throw new AirhostessIdNotFound();
		}
	}

	public ResponseStructure<Airhostess> deleteAirhostessById(int airhostessId) {
		Airhostess airhostess = airhostessDao.fetchAirhostessById(airhostessId);
		if (airhostess != null) {
			responseStructure.setMessage("Sucessfully Airhostess deleted from the DB");
			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setData(airhostessDao.deleteAirhostessById(airhostessId));
			return responseStructure;
		} else {
			throw new AirhostessIdNotFound();
		}
	}

	public ResponseStructure<Airhostess> UpdateAirhostessById(int oldAirhostessId, Airhostess newAirhostess) {
		Airhostess airhostess = airhostessDao.fetchAirhostessById(oldAirhostessId);
		if (airhostess != null) {
			responseStructure.setMessage("Sucessfully Airhostess updated in the DB");
			responseStructure.setStatusCode(HttpStatus.OK.value());
			responseStructure.setData(airhostessDao.UpdateAirhostessById(oldAirhostessId, newAirhostess));
			return responseStructure;
		} else {
			throw new AirhostessIdNotFound();
		}
	}

	public ResponseStructure<Airhostess> fetchAllAirhostess() {
		responseStructureAll.setMessage("Sucessfully  all Airhostess fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(airhostessDao.fetchAllAirhostess());
		return responseStructure;
	}
}

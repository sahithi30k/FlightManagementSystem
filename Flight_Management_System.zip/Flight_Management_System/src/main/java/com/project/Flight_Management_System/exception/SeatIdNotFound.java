package com.project.Flight_Management_System.exception;

public class SeatIdNotFound extends RuntimeException {
	private String message="Seat Id not found in the DB";
	public String getMessage() {
		return message;
	}
}

package com.project.Flight_Management_System.exception;

public class TicketIdNotFound extends RuntimeException {
	private String message="Ticket Id not found in the DB";
	public String getMessage() {
		return message;
	}

}

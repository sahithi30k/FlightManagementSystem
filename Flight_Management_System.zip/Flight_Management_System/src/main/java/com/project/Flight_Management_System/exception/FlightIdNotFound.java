package com.project.Flight_Management_System.exception;

public class FlightIdNotFound extends RuntimeException{
	private String message="flight Id not found in the DB";
	public String getMessage() {
		return message;
	}
}

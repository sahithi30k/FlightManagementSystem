package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.TicketDao;
import com.project.Flight_Management_System.dto.Ticket;
import com.project.Flight_Management_System.exception.TicketIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;
@Service
public class TicketService {
	@Autowired
	TicketDao ticketDao;
	@Autowired
	ResponseStructure<Ticket> responseStructure;
	@Autowired
	ResponseStructureAll<Ticket> responseStructureAll;

	
	public  ResponseStructure<Ticket> saveTicket(Ticket ticket) {
		responseStructure.setMessage("Sucessfully Ticket saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData( ticketDao.saveTicket(ticket));
		return responseStructure;
	}
	
	public  ResponseStructure<Ticket> fetchTicketById(int ticketId) {
	Ticket ticket = ticketDao.fetchTicketById(ticketId);
		if (ticket != null) {
			responseStructure.setMessage("Sucessfully Ticket fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(ticketDao.fetchTicketById(ticketId));
			return responseStructure;
		}else {
			throw new TicketIdNotFound();
		}

	}

	
	public  ResponseStructure<Ticket> deleteTicketById(int ticketId) {
		Ticket ticket = ticketDao.fetchTicketById(ticketId);
		if (ticket != null) {
		responseStructure.setMessage("Sucessfully Ticket deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ticketDao.deleteTicketById(ticketId));
		return responseStructure;
	}else {
		throw new TicketIdNotFound();
	}

}
	
	public  ResponseStructure<Ticket> updateTicketById(int oldTicketId, Ticket newTicket) {
		Ticket ticket = ticketDao.fetchTicketById(oldTicketId);
		if (ticket != null) {
	
		responseStructure.setMessage("Sucessfully ticket updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(ticketDao.updateTicketById(oldTicketId, newTicket));
		return responseStructure;  
	}else {
		throw new TicketIdNotFound();
	}

}
	public  ResponseStructure<Ticket> fetchAllTicket(){
		responseStructureAll.setMessage("Sucessfully  all Tickets fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(ticketDao.fetchAllTicket());
		return responseStructure;
	
	}
	public  ResponseStructure<Ticket> addExistingPaymentToExistingTicket(int ticketId,int paymentId) {
//		return ticketDao.addExistingPaymentToExistingTicket(ticketId, paymentId);
		responseStructure.setMessage("Sucessfully payment adddedto the ticket in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData( ticketDao.addExistingPaymentToExistingTicket(ticketId, paymentId));
		return responseStructure;
	}
}

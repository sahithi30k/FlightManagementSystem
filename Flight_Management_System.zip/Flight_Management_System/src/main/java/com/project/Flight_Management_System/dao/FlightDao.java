package com.project.Flight_Management_System.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.Flight_Management_System.dto.Airhostess;
import com.project.Flight_Management_System.dto.Flight;
import com.project.Flight_Management_System.dto.Passenger;
import com.project.Flight_Management_System.dto.Pilot;
import com.project.Flight_Management_System.repo.FlightRepo;

@Repository
public class FlightDao {

	@Autowired
	FlightRepo flightRepo;

	@Autowired
	AirhostessDao airhostessDao;
	@Autowired
	PilotDao pilotDao;
	@Autowired
	PassengerDao passengerDao;

	public Flight saveFlight(Flight flight) {

		return flightRepo.save(flight);
	}

	public Flight fetchFlightById(int flightId) {
		Optional<Flight> flight = flightRepo.findById(flightId);
		if(flight.isPresent()) {
			return flight.get();
		}
		else {
			return null;
		}
		
	}

	public Flight deleteFlightById(int flightId) {
		Flight flight = fetchFlightById(flightId);
		flightRepo.delete(flight);
		return flight;
	}

	public Flight UpdateFLightById(int oldFlightId, Flight newFlight) {
		newFlight.setFlightId(oldFlightId);
		return flightRepo.save(newFlight);
	}

	public List<Flight> fetchAllFlight() {
		return flightRepo.findAll();
	}

	public Flight addExistingAirhostessToExistingFlight(int airhostessId, int flightId) {
		Flight flight = fetchFlightById(flightId);
		Airhostess airhostess = airhostessDao.fetchAirhostessById(airhostessId);
		List<Airhostess> list = flight.getAirhostesses();
		list.add(airhostess);
		return saveFlight(flight);
	}

	public Flight addNewAirhostessToExistingFlight(int flightId, Airhostess newAirhostess) {
		Flight flight = fetchFlightById(flightId);
		List<Airhostess> list = flight.getAirhostesses();
		list.add(newAirhostess);
		return saveFlight(flight);

	}
	public Flight addExistingPilotToExistingFlight(int pilotId,int flightId) {
		Flight flight = fetchFlightById(flightId);
		Pilot pilot=pilotDao.fetchPilotById(pilotId);
		List<Pilot> list = flight.getPilots();
		list.add(pilot);
		return saveFlight(flight);
	}
	public Flight addNewPilotToExistingFlight(int flightId, Pilot newPilot) {
		Flight flight = fetchFlightById(flightId);
		List<Pilot> list = flight.getPilots();
		list.add(newPilot);
		return saveFlight(flight);

	}
	public Flight addExistingPassengerToExistingFlight(int passengerId,int flightId) {
		Flight flight = fetchFlightById(flightId);
		Passenger passenger =passengerDao.fetchPassengerById(passengerId);
		List<Passenger> list = flight.getPassengers();
		list.add(passenger);
		return saveFlight(flight);
	}
	public Flight addNewPassengerToExistingFlight(int flightId, Passenger newPassenger) {
		Flight flight = fetchFlightById(flightId);
		List<Passenger> list = flight.getPassengers();
		list.add(newPassenger);
		return saveFlight(flight);

	}
}
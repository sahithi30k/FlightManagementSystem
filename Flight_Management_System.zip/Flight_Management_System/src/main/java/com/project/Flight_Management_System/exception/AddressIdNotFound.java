package com.project.Flight_Management_System.exception;

public class AddressIdNotFound extends RuntimeException {
	private String message="address Id not found in the DB";
	public String getMessage() {
		return message;
	}
}

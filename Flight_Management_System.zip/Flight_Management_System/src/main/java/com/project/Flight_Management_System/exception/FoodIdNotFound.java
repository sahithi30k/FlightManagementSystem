package com.project.Flight_Management_System.exception;

public class FoodIdNotFound  extends RuntimeException{
	private String message="Food Id not found in the DB";
	public String getMessage() {
		return message;
	}
}

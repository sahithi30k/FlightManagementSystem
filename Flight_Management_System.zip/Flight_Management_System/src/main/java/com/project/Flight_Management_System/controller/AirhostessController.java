package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Airhostess;
import com.project.Flight_Management_System.service.AirhostessService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class AirhostessController {

	@Autowired
	AirhostessService airhostessService;
	@Operation(summary = "Save airhostess", description = "API is used to save the airhostess")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  airhostess created"),
			@ApiResponse(responseCode = "404", description = "airhostess not found for the given id") })
	@PostMapping("/saveAirhostess")
	public ResponseStructure<Airhostess> saveAirhostess(@RequestBody  Airhostess airhostess) {

		return airhostessService.saveAirhostess(airhostess);
	}
	@Operation(summary = "Fetched aihostess", description = "API is used to fetch the airhostess")
	@ApiResponses(value = { @ApiResponse(responseCode = "302", description = "Successfully  airhostess fetched "),
			@ApiResponse(responseCode = "404", description = "airhostess not found for the given id") })
@GetMapping("/fetchAirhostessById")
	public ResponseStructure<Airhostess> fetchAirhostessById(@RequestParam  int airhostessId) {
	
		return airhostessService.fetchAirhostessById(airhostessId);
	}
@DeleteMapping("/deleteAirhostessById")
	public ResponseStructure<Airhostess> deleteAirhostessById(@RequestParam  int airhostessId) {
		
		return airhostessService.deleteAirhostessById(airhostessId);
	}
@PutMapping("/UpdateAirhostessById")
	public ResponseStructure<Airhostess> UpdateAirhostessById(@RequestParam  int oldAirhostessId,@RequestBody  Airhostess newAirhostess) {
		return  airhostessService.UpdateAirhostessById(oldAirhostessId, newAirhostess);
	}
@GetMapping("/fetchAllAirhostess")
	public ResponseStructure<Airhostess> fetchAllAirhostess() {
		return airhostessService.fetchAllAirhostess();
	}
}

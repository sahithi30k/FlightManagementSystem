package com.project.Flight_Management_System.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Flight_Management_System.dto.Ticket;
import com.project.Flight_Management_System.service.TicketService;
import com.project.Flight_Management_System.util.ResponseStructure;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
@RestController
public class TicketController {
@Autowired
TicketService ticketService;
@Operation(summary = "Save TICKET", description = "API is used to save the TICKET")
@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successfully  ticket created"),
		@ApiResponse(responseCode = "404", description = "ticket not found for the given id") })
	@PostMapping("/saveTicket")
	public ResponseStructure<Ticket> saveTicket(@RequestBody  Ticket ticket) {
		return ticketService.saveTicket(ticket);
	}
	@GetMapping("/fetchTicketById")
	public ResponseStructure<Ticket> fetchTicketById(@RequestParam int ticketId) {
	 return ticketService.fetchTicketById(ticketId);
	}

@DeleteMapping("/deleteTicketById")
	public ResponseStructure<Ticket> deleteTicketById(@RequestParam int ticketId) {
	 return ticketService.deleteTicketById(ticketId);
	}
	@PutMapping("/updateTicketById")
	public ResponseStructure<Ticket> updateTicketById(@RequestParam  int oldTicketId,@RequestBody Ticket newTicket) {
		 return  ticketService.updateTicketById(oldTicketId, newTicket);
	}
	@GetMapping("/fetchAllTicket")
	public ResponseStructure<Ticket> fetchAllTicket(){
		return ticketService.fetchAllTicket();
	}
	@PutMapping("/addExistingPaymentToExistingTicket")
	public ResponseStructure<Ticket> addExistingPaymentToExistingTicket(@RequestParam  int ticketId,@RequestParam   int paymentId) {
		return ticketService.addExistingPaymentToExistingTicket(ticketId, paymentId);
	}



}

package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.PaymentDao;
import com.project.Flight_Management_System.dto.Payment;
import com.project.Flight_Management_System.exception.PaymentIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;
@Service

public class PaymentService {
	@Autowired
	PaymentDao paymentDao;
	@Autowired
	ResponseStructure<Payment> responseStructure;
	@Autowired
	ResponseStructureAll<Payment> responseStructureAll;

	public   ResponseStructure<Payment> savePayment(Payment payment) {
		responseStructure.setMessage("Sucessfully Payment saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(paymentDao.savePayment(payment));
		return responseStructure;
	}
	
	public  ResponseStructure<Payment> fetchPaymentById(int paymentId) {
		Payment payment = paymentDao.fetchPaymentById(paymentId);
		if(payment!=null) {
			responseStructure.setMessage("Sucessfully Payment fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(paymentDao.fetchPaymentById(paymentId));
			return responseStructure;
		}else {
			throw new PaymentIdNotFound();
		}

	}

	
	public  ResponseStructure<Payment> deletePaymentById(int paymentId) {
		Payment payment = paymentDao.fetchPaymentById(paymentId);
		if(payment!=null) {
		responseStructure.setMessage("Sucessfully Payment deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(paymentDao.deletePaymentById(paymentId));
		return responseStructure;
	}else {
		throw new PaymentIdNotFound();
	}

}
	
	public  ResponseStructure<Payment> updatePaymentById(int oldPaymentId, Payment newPayment) {
		Payment payment = paymentDao.fetchPaymentById(oldPaymentId);
		if(payment!=null) {
	
		responseStructure.setMessage("Sucessfully Payment updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(paymentDao.updatePaymentById(oldPaymentId, newPayment));
		return responseStructure;
		
	}else {
		throw new PaymentIdNotFound();
	}

}
	public ResponseStructure<Payment> fetchAllPayment(){
		responseStructureAll.setMessage("Sucessfully  all Payments fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(paymentDao.fetchAllPayment());
		return responseStructure;
		
	}

}

package com.project.Flight_Management_System.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.project.Flight_Management_System.dao.FlightDao;
import com.project.Flight_Management_System.dto.Airhostess;
import com.project.Flight_Management_System.dto.Flight;
import com.project.Flight_Management_System.dto.Passenger;
import com.project.Flight_Management_System.dto.Pilot;
import com.project.Flight_Management_System.exception.FlightIdNotFound;
import com.project.Flight_Management_System.util.ResponseStructure;
import com.project.Flight_Management_System.util.ResponseStructureAll;
@Service
public class FlightService {
@Autowired
FlightDao flightDao;
	
@Autowired
ResponseStructure<Flight> responseStructure;
@Autowired
ResponseStructureAll<Flight> responseStructureAll;

	public ResponseStructure<Flight> saveFlight(Flight flight) {
		responseStructure.setMessage("Sucessfully Flight saved in the DB");
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setData(flightDao.saveFlight(flight));
		return responseStructure;
	}

	public  ResponseStructure<Flight> fetchFlightById(int flightId) {
		Flight flight = flightDao.fetchFlightById(flightId);
		if (flight != null) {
			responseStructure.setMessage("Sucessfully Flight fetched from the DB");
			responseStructure.setStatusCode(HttpStatus.FOUND.value());
			responseStructure.setData(flightDao.fetchFlightById(flightId));
			return responseStructure;
		}else {
			throw new FlightIdNotFound();
		}
	}

	public  ResponseStructure<Flight> deleteFlightById(int flightId) {
		Flight flight = flightDao.fetchFlightById(flightId);
		if (flight != null) {
		responseStructure.setMessage("Sucessfully Flight deleted from the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.deleteFlightById(flightId));
		return responseStructure;
	}else {
		throw new FlightIdNotFound();
	}
}

	public  ResponseStructure<Flight> UpdateFLightById(int oldFlightId, Flight newFlight) {
		Flight flight = flightDao.fetchFlightById(oldFlightId);
		if (flight != null) {
		responseStructure.setMessage("Sucessfully Flight updated in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.UpdateFLightById(oldFlightId, newFlight));
		return responseStructure;
	}else {
		throw new FlightIdNotFound();
	}
}

	public  ResponseStructure<Flight> fetchAllFlight() {
		responseStructureAll.setMessage("Sucessfully  all Flight fetched the DB");
		responseStructureAll.setStatusCode(HttpStatus.FOUND.value());
		responseStructureAll.setData(flightDao.fetchAllFlight());
		return responseStructure;
	}
	public  ResponseStructure<Flight> addExistingAirhostessToExistingFlight(int airhostessId,int flightId) {
		//return flightDao.addExistingAirhostessToExistingFlight(airhostessId, flightId);
		responseStructure.setMessage("Sucessfully Flight saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addExistingAirhostessToExistingFlight(airhostessId, flightId));
		return responseStructure;

	}
	public ResponseStructure<Flight> addNewAirhostessToExistingFlight(int flightId, Airhostess newAirhostess) {
//		return flightDao.addNewAirhostessToExistingFlight(flightId, newAirhostess);
		responseStructure.setMessage("Sucessfully Flight saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addNewAirhostessToExistingFlight(flightId, newAirhostess));
		return responseStructure;

	}
	public  ResponseStructure<Flight> addExistingPilotToExistingFlight(int pilotId,int flightId) {
//		return flightDao.addExistingPilotToExistingFlight(pilotId, flightId);
		responseStructure.setMessage("Sucessfully Flight saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addExistingPilotToExistingFlight(pilotId, flightId));
		return responseStructure;

	}
	public  ResponseStructure<Flight> addNewPilotToExistingFlight(int flightId, Pilot newPilot) {
//		return flightDao.addNewPilotToExistingFlight(flightId, newPilot);
		responseStructure.setMessage("Sucessfully Flight saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addNewPilotToExistingFlight(flightId, newPilot));
		return responseStructure;


	}
	public  ResponseStructure<Flight> addExistingPassengerToExistingFlight(int passengerId,int flightId) {
//		return flightDao.addExistingPassengerToExistingFlight(passengerId, flightId);
		responseStructure.setMessage("Sucessfully Flight saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addExistingPassengerToExistingFlight(passengerId, flightId));
		return responseStructure;

	}
	public  ResponseStructure<Flight> addNewPassengerToExistingFlight(int flightId, Passenger newPassenger) {
		//return flightDao.addNewPassengerToExistingFlight(flightId, newPassenger);
		responseStructure.setMessage("Sucessfully Flight saved in the DB");
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setData(flightDao.addNewPassengerToExistingFlight(flightId, newPassenger));
		return responseStructure;

	}
}
